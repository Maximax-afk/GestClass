from django.contrib import admin
from django.http import HttpResponse
from django.urls import path, include
from cours import views


def home(request) :
    return HttpResponse("Bienvenue sur GestClass"),
    
urlpatterns = [
    path('login/', views.student_login, name='student_login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('admin/', admin.site.urls),
    path('courses/', include('')),   
]