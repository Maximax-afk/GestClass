from django.test import TestCase
from django.urls import Reverse
from .models import Prof, course, Enrollment, Attendance 
import openai

class studentModel(TestCase):
    def test_student_creation(self):
        student = Student.objects.create(identifier="", password="", name="")
        self.assertEqual(student.name, " ")
        self.assertEqual(student.idenifier, "")
        self.assertEqual(str(student),"")

class CourseModel(TestCase):
    def test_course_creation(self):
        teacher = teacher.objects.create(name="", email="")
        course = course.objects.create(name="" , teacher=teacher)
        self.assertEqual(course.teacher,"")
        self.assertEqual(course.teacher,"")
        self.assertEqual(str(course),"")

class EnrollementModel(TestCase):
    def setUp(self):
        self.student = Student.object.create(identifier="", password="", name="")

    def testRéussi(self):
        response = self.client.post(reverse('login'), {'identifier':'', 'password':''})
        self.assertRedirects(response, reverse('mark_attendance', kwargs={'student_id': self.student.id}))

    def testEchoué(self):
        response = self.client.post(reverse('login'), {'identifier': '', 'password': 'mot de passe invalide'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'mot de passe invalide')

class AttendanceModel(TestCase): 
    def setUp(self):
        self.student = Studet.objects.create(identifier='', password='')
        self.course = course.objects.create(name='', prof=self.prof, start_time=timezone.now(), end_time=timezone.now() + timezone.timedelta(hours=1))

    def testAttendnce(self):
        response = self.client.get(reverse('présence', kwargs={'student_id': self.student.id}))
        self.asserEqual(response.status_code, 200)
        attendance = Attendance.objects.filter(student=self.student, course=self.course).first()
        self.assertIsNotNone(attendance)
        self.assertTrue(attendance.present)

class replace_with_aiModel(TestCase):
    def setUp(self):
        self.teacher= teacher.objects.create(name="", email="")
        self.course= course.objects.create(name="", teacher=self.teacher, start_time=timezone.now() - timezone.timedelta(minutes=16), end_time=timezone.now() + timezone.timedelta(hours=1))
    
    def test_absence_prof(self):
        response = self.client.get(reverse('check_teacher_availability', kwargs={'classroonm_id':self.classroom.id}))
        self.assertRedirects(response, reverse('replace_with_ai', kwargs={'classroonm_id':self.classroom.id}))
        self.assertTrue(course.objects.get(id=self.course.id).ai_active)

    def CoursAnnulé(self):
        openai.api_key = None
        response = self.client.get(reverse('replace_with_ai', kwargs={'course_id': self.course.id}))
        self.assertRedirects(response, reverse('cours Annulé'))
        self.assertFalse(Course.objects.get(id=self.course.id).ai_active)


        