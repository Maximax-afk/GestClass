from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.core.mail import send_mail
from .models import Student, Course, Attendance
from datetime import datetime, timedelta
from .models import Course, Attendance
import time

def student_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            try:
                student = Student.objects.get(user=user)
                login(request, user)
                messages.success(request, f'{student.user.username} is now present.')
                return redirect('dashboard')
            except Student.DoesNotExist:
                messages.error(request, 'You are not registered as a student.')
        else:
            messages.error(request, 'Invalid login credentials.')
    return render(request, 'courses/student_login.html')

def dashboard(request):
    if request.user.is_authenticated:
        student = Student.objects.get(user=request.user)
        enrollments = student.enrollment_set.all()
        context = {
            'student': student,
            'enrollments': enrollments
        }
        return render(request, 'courses/dashboard.html', context)
    else:
        return redirect('student_login')


def check_teacher_availability():
    courses = Course.objects.filter(teacher__isnull=False)
    for course in courses:
        if not course.teacher.user.is_online():  
            if course.teacher_absent_time() > timedelta(minutes=15):  
                replace_with_ai(course)

def replace_with_ai(course):
    students = course.students.all()
    for student in students:
        send_mail(
            'Teacher Absent Notification',
            'Your teacher is absent today. The AI will replace him.',
            'no-reply@yourdomain.com',
            [student.user.email],
            fail_silently=False,
        )

