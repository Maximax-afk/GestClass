import time
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from django.conf import settings

import requests

from cours.models import Course

class Command(BaseCommand):
    help = 'Manage teachers and replace with AI if absent'

    def handle(self, *args, **kwargs):
        self.check_teacher_availability()

    def check_teacher_availability(self):
        courses = Course.objects.filter(teacher__isnull=False)
        for course in courses:
            teacher = course.teacher
            # Assuming there's a method to check online status of the teacher
            if not self.is_teacher_online(teacher):
                if self.teacher_absent_time(teacher) > timedelta(minutes=15):
                    self.replace_with_ai(course)

    def is_teacher_online(self, teacher):
        return False  

    def teacher_absent_time(self, teacher):
        return timedelta(hours=1)

    def replace_with_ai(self, course):
        students = course.students.all()
        for student in students:
            send_mail(
                'Teacher Absent Notification',
                'Your teacher is absent today. The AI will replace him.',
                settings.DEFAULT_FROM_EMAIL,
                [student.user.email],
                fail_silently=False,
            )

        prompt = f"Conduct the {course.name} class."
        response = self.call_chatgpt_api(prompt);
        if response:
            print(f"AI Response: {response}")
        else:
            print("AI failed to respond, canceling the course.")

    def call_chatgpt_api(self, prompt):
        api_url = "https://api.example.com/chatgpt"
        headers = {
            'Authorization': f'Bearer {settings.CHATGPT_API_KEY}',
            'Content-Type': 'application/json'
        }
        data = {'prompt': prompt}
        try:
            response = requests.post(api_url, json=data, headers=headers)
            if response.status_code == 200:
                return response.json().get('response')
            else:
                print(f"Error calling API: {response.status_code} {response.text}")
                return None
        except Exception as e:
            print(f"Exception while calling API: {e}")
            return None